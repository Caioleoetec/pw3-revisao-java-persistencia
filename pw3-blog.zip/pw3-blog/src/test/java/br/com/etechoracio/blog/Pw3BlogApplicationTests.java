package br.com.etechoracio.blog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pw3BlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
