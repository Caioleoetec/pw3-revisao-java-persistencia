package br.com.etechoracio.blog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pw3BlogApplication {

	public static void main(String[] args) {
		SpringApplication.run(Pw3BlogApplication.class, args);
	}

}
